# Home - SMART Base Clinical v2.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base-clinical/ImplementationGuide/smart.who.int.base-clinical | *Version*:2.0.0 |
| Draft as of 2026-09-01 | *Computable Name*:SMARTBaseClinical |

### Overview

This implementation guide contains clinical conformance resources for use in all clinically-focused WHO SMART Guidelines implementation guides.

See the [SMART IG Starter Kit](https://smart.who.int/ig-starter-kit/) for more information on building and using WHO SMART Guidelines.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.base-clinical.r4)](package.r4.tgz) and [R4B (smart.who.int.base-clinical.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Diagnosis Role](http://terminology.hl7.org/7.3.0/CodeSystem-diagnosis-role.html): [SGEpisodeOfCare](StructureDefinition-sg-episodeofcare.md)
* [LibraryType](http://terminology.hl7.org/7.3.0/CodeSystem-library-type.html): [WHOCommon](Library-WHOCommon.md)
* [MedicationRequest Category Codes](http://terminology.hl7.org/7.3.0/CodeSystem-medicationrequest-category.html): [SGMedicationRequest](StructureDefinition-sg-medicationrequest.md)
* [contactRole2](http://terminology.hl7.org/7.3.0/CodeSystem-v2-0131.html): [SGRelatedPerson](StructureDefinition-sg-relatedperson.md)
* [RoleCode](http://terminology.hl7.org/7.3.0/CodeSystem-v3-RoleCode.html): [SGLocation](StructureDefinition-sg-location.md) and [SGRelatedPerson](StructureDefinition-sg-relatedperson.md)


